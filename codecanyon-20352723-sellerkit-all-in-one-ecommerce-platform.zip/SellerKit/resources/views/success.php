<?php echo $header?>
<style>
	.bg,.cover{
	background:#69DD95;
	}
</style>
<div class="container landing-cover">
	<div class="not-found bg">
		<h1><?=translate("Success");?></h1>
		<h5><?=translate("Your order has been placed successfully");?></h5>
	</div>
</div>
<?php echo $footer?>