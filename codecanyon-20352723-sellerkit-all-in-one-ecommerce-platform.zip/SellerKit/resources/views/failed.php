<?php echo $header?>
<style>
	.bg,.cover{
	background:#F26175;
	}
</style>
<div class="container landing-cover">
	<div class="not-found bg">
		<h1><?=translate("Failed");?></h1>
		<h5><?=translate("The payment has been canceled !");?></h5>
	</div>
</div>
<?php echo $footer?>	